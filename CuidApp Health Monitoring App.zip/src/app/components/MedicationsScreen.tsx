import { Pill, Clock, Plus, Bell, X, Edit2, Trash2 } from "lucide-react";
import { useState } from "react";

interface Medication {
  id: number;
  name: string;
  dose: string;
  frequency: string;
  times: string[];
  color: string;
  notes?: string;
}

export function MedicationsScreen() {
  const [medications, setMedications] = useState<Medication[]>([
    {
      id: 1,
      name: "Losartán",
      dose: "50mg",
      frequency: "1 vez al día",
      times: ["8:00 AM"],
      color: "blue",
    },
    {
      id: 2,
      name: "Metformina",
      dose: "850mg",
      frequency: "2 veces al día",
      times: ["8:00 AM", "8:00 PM"],
      color: "green",
    },
    {
      id: 3,
      name: "Atorvastatina",
      dose: "20mg",
      frequency: "1 vez al día",
      times: ["8:00 PM"],
      color: "purple",
    },
    {
      id: 4,
      name: "Omeprazol",
      dose: "20mg",
      frequency: "1 vez al día",
      times: ["7:30 AM"],
      color: "orange",
    },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingMed, setEditingMed] = useState<Medication | null>(null);
  const [newMedication, setNewMedication] = useState({
    name: "",
    dose: "",
    frequency: "",
    times: [""],
    color: "blue",
    notes: "",
  });

  const getColorClasses = (color: string) => {
    const colors = {
      blue: "bg-blue-100 text-blue-700 border-blue-200",
      green: "bg-green-100 text-green-700 border-green-200",
      purple: "bg-purple-100 text-purple-700 border-purple-200",
      orange: "bg-orange-100 text-orange-700 border-orange-200",
      red: "bg-red-100 text-red-700 border-red-200",
      pink: "bg-pink-100 text-pink-700 border-pink-200",
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const handleAddMedication = () => {
    if (newMedication.name && newMedication.dose && newMedication.frequency) {
      const validTimes = newMedication.times.filter((time) => time.trim() !== "");
      if (validTimes.length === 0) return;

      const medication: Medication = {
        id: Date.now(),
        ...newMedication,
        times: validTimes,
      };
      setMedications([...medications, medication]);
      setNewMedication({
        name: "",
        dose: "",
        frequency: "",
        times: [""],
        color: "blue",
        notes: "",
      });
      setShowAddModal(false);
    }
  };

  const handleEditMedication = () => {
    if (editingMed && newMedication.name && newMedication.dose && newMedication.frequency) {
      const validTimes = newMedication.times.filter((time) => time.trim() !== "");
      if (validTimes.length === 0) return;

      setMedications(
        medications.map((med) =>
          med.id === editingMed.id
            ? { ...med, ...newMedication, times: validTimes }
            : med
        )
      );
      setShowEditModal(false);
      setEditingMed(null);
      setNewMedication({
        name: "",
        dose: "",
        frequency: "",
        times: [""],
        color: "blue",
        notes: "",
      });
    }
  };

  const handleDeleteMedication = (id: number) => {
    if (confirm("¿Estás seguro de eliminar este medicamento?")) {
      setMedications(medications.filter((med) => med.id !== id));
    }
  };

  const openEditModal = (med: Medication) => {
    setEditingMed(med);
    setNewMedication({
      name: med.name,
      dose: med.dose,
      frequency: med.frequency,
      times: [...med.times],
      color: med.color,
      notes: med.notes || "",
    });
    setShowEditModal(true);
  };

  const addTimeSlot = () => {
    setNewMedication({
      ...newMedication,
      times: [...newMedication.times, ""],
    });
  };

  const removeTimeSlot = (index: number) => {
    const newTimes = newMedication.times.filter((_, idx) => idx !== index);
    setNewMedication({
      ...newMedication,
      times: newTimes.length > 0 ? newTimes : [""],
    });
  };

  const updateTimeSlot = (index: number, value: string) => {
    const newTimes = [...newMedication.times];
    newTimes[index] = value;
    setNewMedication({
      ...newMedication,
      times: newTimes,
    });
  };

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl text-gray-900">Mis Medicamentos</h2>
          <p className="text-sm text-gray-500 mt-1">
            {medications.length} medicamentos activos
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>

      {/* Medications List */}
      <div className="space-y-3">
        {medications.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center">
            <Pill className="w-16 h-16 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">No hay medicamentos registrados</p>
            <button
              onClick={() => setShowAddModal(true)}
              className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Agregar primero medicamento
            </button>
          </div>
        ) : (
          medications.map((med) => (
            <div
              key={med.id}
              className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100"
            >
              <div className="flex items-start gap-4">
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center border ${getColorClasses(
                    med.color
                  )}`}
                >
                  <Pill className="w-7 h-7" />
                </div>
                <div className="flex-1">
                  <h3 className="text-base text-gray-900">{med.name}</h3>
                  <p className="text-sm text-gray-500 mt-1">{med.dose}</p>
                  <p className="text-xs text-gray-400 mt-1">{med.frequency}</p>

                  {/* Reminder times */}
                  <div className="flex flex-wrap gap-2 mt-3">
                    {med.times.map((time, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-1 bg-gray-50 px-3 py-1.5 rounded-lg"
                      >
                        <Bell className="w-3.5 h-3.5 text-gray-500" />
                        <span className="text-xs text-gray-700">{time}</span>
                      </div>
                    ))}
                  </div>

                  {med.notes && (
                    <p className="text-xs text-gray-500 mt-2 italic">{med.notes}</p>
                  )}
                </div>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => openEditModal(med)}
                    className="w-8 h-8 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center hover:bg-blue-100 transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteMedication(med.id)}
                    className="w-8 h-8 bg-red-50 text-red-600 rounded-lg flex items-center justify-center hover:bg-red-100 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Weekly Summary */}
      {medications.length > 0 && (
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-5 border border-blue-100">
          <div className="flex items-center gap-2 mb-3">
            <Clock className="w-5 h-5 text-blue-600" />
            <h3 className="text-base text-gray-900">Resumen semanal</h3>
          </div>
          <div className="grid grid-cols-7 gap-2">
            {["L", "M", "M", "J", "V", "S", "D"].map((day, idx) => (
              <div key={idx} className="text-center">
                <p className="text-xs text-gray-500 mb-2">{day}</p>
                <div
                  className={`h-10 rounded-lg ${
                    idx < 5
                      ? "bg-green-500"
                      : idx === 5
                      ? "bg-green-300"
                      : "bg-gray-200"
                  }`}
                />
                <p className="text-xs text-gray-600 mt-1">
                  {idx < 5 ? "100%" : idx === 5 ? "50%" : "-"}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tips */}
      <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200">
        <p className="text-sm text-amber-900">
          💡 <span className="font-medium">Consejo:</span> Toma tus
          medicamentos siempre a la misma hora para mejores resultados.
        </p>
      </div>

      {/* Add/Edit Medication Modal */}
      {(showAddModal || showEditModal) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h3 className="text-xl text-gray-900">
                {showEditModal ? "Editar medicamento" : "Nuevo medicamento"}
              </h3>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setShowEditModal(false);
                  setEditingMed(null);
                  setNewMedication({
                    name: "",
                    dose: "",
                    frequency: "",
                    times: [""],
                    color: "blue",
                    notes: "",
                  });
                }}
                className="w-8 h-8 bg-gray-100 text-gray-600 rounded-lg flex items-center justify-center hover:bg-gray-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-sm text-gray-700 mb-1 block">
                  Nombre del medicamento *
                </label>
                <input
                  type="text"
                  value={newMedication.name}
                  onChange={(e) =>
                    setNewMedication({ ...newMedication, name: e.target.value })
                  }
                  placeholder="Ej: Losartán"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-sm text-gray-700 mb-1 block">
                  Dosis *
                </label>
                <input
                  type="text"
                  value={newMedication.dose}
                  onChange={(e) =>
                    setNewMedication({ ...newMedication, dose: e.target.value })
                  }
                  placeholder="Ej: 50mg"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-sm text-gray-700 mb-1 block">
                  Frecuencia *
                </label>
                <input
                  type="text"
                  value={newMedication.frequency}
                  onChange={(e) =>
                    setNewMedication({
                      ...newMedication,
                      frequency: e.target.value,
                    })
                  }
                  placeholder="Ej: 1 vez al día"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-sm text-gray-700 mb-1 block">
                  Horarios *
                </label>
                <div className="space-y-2">
                  {newMedication.times.map((time, index) => (
                    <div key={index} className="flex gap-2">
                      <input
                        type="text"
                        value={time}
                        onChange={(e) => updateTimeSlot(index, e.target.value)}
                        placeholder="Ej: 8:00 AM"
                        className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      {newMedication.times.length > 1 && (
                        <button
                          onClick={() => removeTimeSlot(index)}
                          className="w-10 h-10 bg-red-50 text-red-600 rounded-lg flex items-center justify-center hover:bg-red-100 transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                  <button
                    onClick={addTimeSlot}
                    className="w-full py-2 border-2 border-dashed border-gray-300 text-gray-600 rounded-xl hover:border-blue-400 hover:text-blue-600 transition-colors text-sm"
                  >
                    + Agregar otro horario
                  </button>
                </div>
              </div>

              <div>
                <label className="text-sm text-gray-700 mb-1 block">Color</label>
                <div className="flex gap-2 flex-wrap">
                  {["blue", "green", "purple", "orange", "red", "pink"].map(
                    (color) => (
                      <button
                        key={color}
                        onClick={() =>
                          setNewMedication({ ...newMedication, color })
                        }
                        className={`w-10 h-10 rounded-lg border-2 transition-all ${
                          newMedication.color === color
                            ? "border-gray-900 scale-110"
                            : "border-gray-200"
                        } ${getColorClasses(color)}`}
                      >
                        <Pill className="w-5 h-5 mx-auto" />
                      </button>
                    )
                  )}
                </div>
              </div>

              <div>
                <label className="text-sm text-gray-700 mb-1 block">
                  Notas (opcional)
                </label>
                <textarea
                  value={newMedication.notes}
                  onChange={(e) =>
                    setNewMedication({ ...newMedication, notes: e.target.value })
                  }
                  placeholder="Ej: Tomar con comida"
                  rows={3}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setShowEditModal(false);
                  setEditingMed(null);
                  setNewMedication({
                    name: "",
                    dose: "",
                    frequency: "",
                    times: [""],
                    color: "blue",
                    notes: "",
                  });
                }}
                className="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={showEditModal ? handleEditMedication : handleAddMedication}
                className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
              >
                {showEditModal ? "Guardar cambios" : "Agregar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
