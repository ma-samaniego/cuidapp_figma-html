import { Camera, Sparkles, Info, AlertCircle, Check } from "lucide-react";
import { useState } from "react";

type ScanState = "ready" | "scanning" | "result";

export function ScannerScreen() {
  const [scanState, setScanState] = useState<ScanState>("ready");
  const [scannedMed, setScannedMed] = useState<any>(null);

  const handleScan = () => {
    setScanState("scanning");

    // Simulate AI processing
    setTimeout(() => {
      setScannedMed({
        name: "Ibuprofeno",
        presentation: "400mg comprimidos",
        laboratory: "Laboratorios Varifarma",
        activeIngredient: "Ibuprofeno",
        type: "Antiinflamatorio no esteroideo (AINE)",
        uses: [
          "Alivio del dolor leve a moderado",
          "Reducción de fiebre",
          "Tratamiento de inflamación",
        ],
        dosage: "Adultos: 200-400mg cada 4-6 horas, máximo 1200mg al día",
        warnings: [
          "No usar en caso de alergia a AINEs",
          "Consulte a su médico si tiene problemas estomacales",
          "No exceder la dosis recomendada",
        ],
        sideEffects: "Náuseas, dolor de estómago, mareos",
      });
      setScanState("result");
    }, 2000);
  };

  const resetScan = () => {
    setScanState("ready");
    setScannedMed(null);
  };

  if (scanState === "result" && scannedMed) {
    return (
      <div className="p-4 space-y-4">
        {/* Success Header */}
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-5 text-white shadow-lg">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <Check className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-xl">¡Medicamento identificado!</h2>
              <p className="text-green-100 text-sm">Análisis completado</p>
            </div>
          </div>
        </div>

        {/* Medication Info */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <h3 className="text-2xl text-gray-900">{scannedMed.name}</h3>
          <p className="text-sm text-gray-500 mt-1">
            {scannedMed.presentation}
          </p>
          <p className="text-xs text-gray-400 mt-1">{scannedMed.laboratory}</p>

          <div className="mt-4 p-3 bg-blue-50 rounded-xl border border-blue-100">
            <p className="text-sm text-blue-900">
              <span className="font-medium">Principio activo:</span>{" "}
              {scannedMed.activeIngredient}
            </p>
            <p className="text-sm text-blue-900 mt-1">
              <span className="font-medium">Tipo:</span> {scannedMed.type}
            </p>
          </div>
        </div>

        {/* Uses */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-3">
            <Info className="w-5 h-5 text-blue-600" />
            <h4 className="text-base text-gray-900">Usos principales</h4>
          </div>
          <ul className="space-y-2">
            {scannedMed.uses.map((use: string, idx: number) => (
              <li key={idx} className="flex gap-2 text-sm text-gray-700">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>{use}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Dosage */}
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl p-4 border border-purple-200">
          <h4 className="text-sm text-purple-900 mb-2">Dosificación</h4>
          <p className="text-sm text-purple-800">{scannedMed.dosage}</p>
        </div>

        {/* Warnings */}
        <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200">
          <div className="flex items-center gap-2 mb-3">
            <AlertCircle className="w-5 h-5 text-amber-600" />
            <h4 className="text-base text-amber-900">Advertencias</h4>
          </div>
          <ul className="space-y-2">
            {scannedMed.warnings.map((warning: string, idx: number) => (
              <li key={idx} className="flex gap-2 text-sm text-amber-800">
                <span className="mt-0.5">⚠️</span>
                <span>{warning}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Side Effects */}
        <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200">
          <h4 className="text-sm text-gray-900 mb-2">Efectos secundarios</h4>
          <p className="text-sm text-gray-700">{scannedMed.sideEffects}</p>
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <button
            onClick={resetScan}
            className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition-colors"
          >
            Escanear otro
          </button>
          <button className="flex-1 bg-gray-100 text-gray-700 px-6 py-3 rounded-xl hover:bg-gray-200 transition-colors">
            Guardar
          </button>
        </div>

        <p className="text-xs text-center text-gray-500 px-4">
          Esta información es referencial. Consulte siempre con un profesional
          de la salud antes de tomar cualquier medicamento.
        </p>
      </div>
    );
  }

  if (scanState === "scanning") {
    return (
      <div className="h-full flex items-center justify-center p-4">
        <div className="text-center">
          <div className="relative inline-block mb-6">
            <div className="w-24 h-24 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
            <Sparkles className="w-12 h-12 text-blue-600 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
          </div>
          <h3 className="text-xl text-gray-900 mb-2">Analizando medicamento</h3>
          <p className="text-sm text-gray-500">
            La IA está identificando el producto...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Camera View */}
      <div className="flex-1 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 relative overflow-hidden">
        {/* Camera Frame Overlay */}
        <div className="absolute inset-0 flex items-center justify-center p-8">
          <div className="relative w-full max-w-xs aspect-square">
            {/* Corner Borders */}
            <div className="absolute top-0 left-0 w-16 h-16 border-t-4 border-l-4 border-blue-500 rounded-tl-2xl" />
            <div className="absolute top-0 right-0 w-16 h-16 border-t-4 border-r-4 border-blue-500 rounded-tr-2xl" />
            <div className="absolute bottom-0 left-0 w-16 h-16 border-b-4 border-l-4 border-blue-500 rounded-bl-2xl" />
            <div className="absolute bottom-0 right-0 w-16 h-16 border-b-4 border-r-4 border-blue-500 rounded-br-2xl" />
          </div>
        </div>

        {/* Simulated Camera Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="w-full h-full bg-gradient-to-br from-blue-500 to-purple-500" />
        </div>
      </div>

      {/* Instructions */}
      <div className="bg-white p-6 space-y-4">
        <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-xl border border-blue-100">
          <Sparkles className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
          <div>
            <h3 className="text-base text-blue-900 mb-1">
              Escáner con IA
            </h3>
            <p className="text-sm text-blue-700">
              Coloca el medicamento dentro del recuadro y presiona el botón para
              identificarlo automáticamente.
            </p>
          </div>
        </div>

        {/* Scan Button */}
        <button
          onClick={handleScan}
          className="w-full bg-blue-600 text-white px-6 py-4 rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 shadow-lg"
        >
          <Camera className="w-6 h-6" />
          <span className="text-lg">Escanear medicamento</span>
        </button>

        <p className="text-xs text-center text-gray-500">
          El reconocimiento funciona con la mayoría de medicamentos comerciales
        </p>
      </div>
    </div>
  );
}